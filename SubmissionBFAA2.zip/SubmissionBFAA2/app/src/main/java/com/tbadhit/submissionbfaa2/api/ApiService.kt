package com.tbadhit.submissionbfaa2.api

import com.tbadhit.submissionbfaa2.model.ResponseSearch
import com.tbadhit.submissionbfaa2.model.ResponseUser
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUser(
        @Query("q") q: String
    ): Call<ResponseSearch>


    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<ResponseUser>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollower(
        @Path("username") username: String
    ): Call<ArrayList<ResponseUser>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<ArrayList<ResponseUser>>

}