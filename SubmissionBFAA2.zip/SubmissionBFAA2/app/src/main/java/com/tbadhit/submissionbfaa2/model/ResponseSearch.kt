package com.tbadhit.submissionbfaa2.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class ResponseSearch(
    @field:SerializedName("items")
    val listUsers: ArrayList<ResponseUser>
) : Parcelable
